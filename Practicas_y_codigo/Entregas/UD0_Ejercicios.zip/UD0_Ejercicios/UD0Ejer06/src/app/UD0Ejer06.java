/*
 Crea un programa que tendrá tres fases:
1) En la primera fase, el usuario introducirá números enteros positivos,
que se guardarán en un ArrayList (esta fase terminará cuando introduzca
un número negativo, que no se guardará).
2) En la segunda fase, el usuario introducirá números enteros positivos
de uno en uno, a lo que se le contestará si el correspondiente número
está o no en la lista de datos que se habían introducido inicialmente.
Cuando introduzca nuevamente un número negativo, terminará la fase de
búsqueda.
3) Por último, se mostrarán ordenados los datos que contiene el
ArrayList.
 */
package app;

import java.util.ArrayList;
import java.util.Scanner;

public class UD0Ejer06 {

    public static ArrayList<Integer> leePositivos() {

        boolean positivo;
        
        ArrayList<Integer> positivos = new ArrayList<Integer>();
        
        do {
            int numero;
    
            System.out.println("Introduce un numero entero (negativo para terminar): ");
            Scanner entrada = new Scanner(System.in);
            numero = Integer.parseInt(entrada.nextLine());
            positivo = numero > 0;

            if (positivo) {
                positivos.add(numero);
            }

        } while (positivo);

        System.out.println("Ya tengo la lista de numeros.");
        
        return positivos;

    }
    
    public static void confirmaNumero(ArrayList<Integer> positivos) {

        boolean positivo;
        
        do {
            int numero;
    
            System.out.println("Introduce de nuevo un numero entero: ");
            Scanner entrada = new Scanner(System.in);
            numero = Integer.parseInt(entrada.nextLine());
            positivo = numero > 0;

            if (positivo && positivos.contains(numero)) {
                System.out.println("El número está en la lista.");
            } else {
            
                System.out.println("Este número no está en la lista.");
            }
               

        } while (positivo);

        
        muestra(positivos);

    }
    
    public static void muestra (ArrayList<Integer> numeros){
        
        System.out.println("Valores introducidos: ");
        
        for (Integer numero : numeros) {
            System.out.println(numero);
        }
        
    }
    

    public static void main(String[] args) {

        ArrayList positivos =  leePositivos();
        
        confirmaNumero(positivos);
        
        
    }

}
