/*
Crea una variante del ejercicio UD0Ejer06 en la que los datos no serán
numéricos, sino cadenas de texto, de modo que cada fase terminará cuando
se introduzca la palabra "fin".
 */
package app;

import java.util.ArrayList;
import java.util.Scanner;

public class UD0Ejer07 {

    public static ArrayList<String> leePalabras() {
        
        ArrayList<String> palabras = new ArrayList<>();
        String termina = "fin";
        
        String palabra;
        do {
    
            System.out.println("Introduce una palabra ('fin' para terminar): ");
            Scanner entrada = new Scanner(System.in);
            palabra = entrada.nextLine();
            
            if(!termina.equals(palabra)){
                palabras.add(palabra);
            }
            

        } while (!termina.equals(palabra));

        System.out.println("Ya tenemos una lista de palabras.");
        
        return palabras;

    }
    
    public static void confirmaPalabra(ArrayList<String> palabras) {

        String termina = "fin";
        String palabra;
        
        do {
            
            System.out.println("Introduce de nuevo una palabra ('fin' para terminar): ");
            Scanner entrada = new Scanner(System.in);
            palabra = entrada.nextLine();

            if (palabras.contains(palabra)) {
                System.out.println(palabra + " aparece");
            } else {
            
                System.out.println(palabra + " no existe");
            }
               

        } while (!termina.equals(palabra));

        
        muestra(palabras);

    }
    
    public static void muestra (ArrayList<String> palabras){
        
        System.out.println("Palabras introducidas: ");
        
        for (String palabra : palabras) {
            System.out.println(palabra);
        }
        
    }
    
    public static void main(String[] args) {
       
        ArrayList<String> palabras = leePalabras();
        
        confirmaPalabra(palabras);
        
    }
    
}
