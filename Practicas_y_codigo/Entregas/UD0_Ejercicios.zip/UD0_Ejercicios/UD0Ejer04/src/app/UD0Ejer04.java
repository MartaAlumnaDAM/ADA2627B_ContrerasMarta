/*
Pide al usuario un número del 1 al 12 y muestra el nombre del
correspondiente mes, usando un array de cadenas de texto en el que
estarán almacenados dichos nombres.
*/
package app;

import java.util.ArrayList;
import java.util.Scanner;


public class UD0Ejer04 {

    public static void main(String[] args) {
        System.out.print("Introduce un número entero del 1 al 12: ");
        Scanner entrada = new Scanner(System.in);
        int numero = entrada.nextInt();
        entrada.nextLine();
        
        String [] meses = {"Enero", "Febrero", "Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
        
        System.out.println("El mes es " + meses[numero - 1]);
        
    }
    
}
