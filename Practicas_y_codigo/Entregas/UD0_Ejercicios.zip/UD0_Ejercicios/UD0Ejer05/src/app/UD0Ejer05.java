/*
 Pide al usuario un número entero y di si es (o no) un palíndromo primo,
con la ayuda de dos funciones booleanas "esPrimo" y "esPalindromo".
Algunos ejemplos son: 2,3 5, 7, 11,101,131,151,181,191,313,353,373,383,727,757,787,797,919,929,10301...
 */
package app;

import java.util.Scanner;

public class UD0Ejer05 {

    public static void main(String[] args) {
        
        System.out.println("Introduce un numero entero: ");
        Scanner entrada = new Scanner(System.in);
        int numero = entrada.nextInt();
        
        boolean esPrimo = esPrimo(numero);
        boolean esPalindromo = esPalindromo(numero);
        
        if(esPrimo && esPalindromo) System.out.println("El numero " + numero + " es primo y es palindromo.");
        if(esPrimo && !esPalindromo) System.out.println("El numero " + numero + " es primo y NO es palindromo.");
        if(!esPrimo && esPalindromo) System.out.println("El numero " + numero + " NO es primo y es palindromo.");
        if(!esPrimo && !esPalindromo) System.out.println("El numero " + numero + " NO es primo y NO es palindromo.");
        
        /*Otra forma de mostrarlo*/
        
        String textoPrimo = esPrimo ? " es primo " : " NO es primo ";
        String textoPalindromo = esPalindromo ? " es palindromo " : " NO es palindromo.";
        
        System.out.println("El numero " + numero + textoPrimo + "y" + textoPalindromo);
    }
    
    public static boolean esPrimo(int numero){
        
        int contador = 2;
        boolean primo = true;
        
        while((primo) && (contador != numero)){
            if((numero % contador) == 0){
                primo = false;
            }
            contador++;
        }
        return primo;
    }
    
    public static boolean esPalindromo(int numero){
        String sPalabra = String.valueOf(numero);
        int inc = 0;
        int des = sPalabra.length()-1;
        boolean palindromo = true;
        
        while((inc<des) && (palindromo)){
            if(sPalabra.charAt(inc) == sPalabra.charAt(des)){
                inc++;
                des--;
            } else{
                palindromo = false;
            }
        }
        return palindromo;
    }
    
}
