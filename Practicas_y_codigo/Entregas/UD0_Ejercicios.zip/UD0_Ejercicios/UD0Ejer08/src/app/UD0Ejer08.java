/*
 Crea una variante del mejorada ejercicio UD0Ejer07, en la que la lista
de datos será una clase ListaDeDatos, con métodos públicos
• "void incluir(texto)",
• "boolean contiene(texto)" y
• "void mostrarDatosOrdenados()".
 */
package app;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author marta contreras
 */
class ListaDeDatos {

    private ArrayList<String> palabras = new ArrayList<>();

    public void incluir(String palabra) {
        palabras.add(palabra);
            
    }
    
    public boolean contiene(String palabra){
        boolean existe = false;
        
        if(palabras.contains(palabra)){
            existe = true;
        }
        return existe;
    }
    
    public void mostrarDatosOrdenados(){

        Collections.sort(palabras);
    
        System.out.println("Valores introducidos: ");
        palabras.forEach(palabra -> {System.out.println(" - " + palabra);});
    }

}

public class UD0Ejer08 {

    public static void main(String[] args) {
        
        System.out.println("Introduce una palabra ('fin' para terminar): ");
        Scanner entrada = new Scanner(System.in);
        String palabra = entrada.nextLine();
        
        String finaliza = "fin";
        
        ListaDeDatos datos = new ListaDeDatos();
        
        do {

            System.out.println("Introduce una palabra ('fin' para terminar): ");
            palabra = entrada.nextLine();
            
            if(datos.contiene(palabra)){
                System.out.println("La palabra " + palabra + " ya está en la lista.");
               
            } else {
                datos.incluir(palabra);
            }
            
        } while (!finaliza.equals(palabra));
        
        datos.mostrarDatosOrdenados();
        
    }

}
