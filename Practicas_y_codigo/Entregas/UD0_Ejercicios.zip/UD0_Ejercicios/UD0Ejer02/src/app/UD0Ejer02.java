/*
Pide al usuario un número entero y muéstra su factorial.
El factorial de un número se define en principio como el producto de
todos los números enteros positivos desde 1 (es decir, los números
naturales) hasta n.
Ejemplo: Factorial de 4 = 1 * 2 * 3 * 4 = 24
 */
package app;

import java.util.Scanner;

public class UD0Ejer02 {

    
    public static void main(String[] args) {
        
        System.out.println("Dame un nùmero entero: ");
        
        Scanner teclado = new Scanner(System.in);
        
        int numero = teclado.nextInt();
        
        int factorial = 1;
        
        for (int i = 1; i <= numero; i++) {
                
            factorial *= i;
            
        }
        
        System.out.println("El factorial de " + numero + " es " + factorial);
        
    }

}
