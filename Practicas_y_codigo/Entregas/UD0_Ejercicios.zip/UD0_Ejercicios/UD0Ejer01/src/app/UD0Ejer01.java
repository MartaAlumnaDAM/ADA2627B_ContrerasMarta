/*
Crea un programa que muestre en pantalla el texto "Dime tu nombre: " y
después, en la misma línea, lea el nombre del usuario, que puede
contener espacios.
Luego escribirá 5 veces "Hola, " seguido por el nombre del usuario, en 5
líneas distintas.
 */
package app;

import java.util.Scanner;

public class UD0Ejer01 {

    public static void main(String[] args) {

        System.out.print("Dime tu nombre: ");
        Scanner teclado = new Scanner(System.in);
        String nombre = teclado.nextLine();
        
        for (int i = 0; i < 5; i++) {
            System.out.println("Hola " + nombre);
        }
        
    }

}
