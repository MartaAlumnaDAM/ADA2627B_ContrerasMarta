
package app;

import clases.Portales;


public class IA_JSON_a_XML {

    public static void main(String[] args) {

        // **************************************
        // JSON - Leer 
        String jsonList = "";
                
        System.out.println(jsonList);
        
        // **************************************
        // Mapeo
        Portales portales = new Portales();
       
        // **************************************
        // XML - Escribir 
        String xmlPortales = "";

        System.out.println(xmlPortales);
        
        
        
    }
    
    
    
}
